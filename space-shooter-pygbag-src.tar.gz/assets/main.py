"""
Pygame Tutorial 10: Simple Game Project - Space Shooter
This tutorial brings together all concepts from previous tutorials:
- Complete game with player, enemies, projectiles
- Score system and power-ups
- Particle effects and animations
- Game states and progression
"""

import asyncio
import pygame
import sys
import random
import math

# Initialize pygame
pygame.init()

# damge sound
damage_sound = pygame.mixer.Sound("crash.ogg")


# Set up the display
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Space Shooter - Pygame Tutorial 10")

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
PURPLE = (128, 0, 128)
ORANGE = (255, 165, 0)
CYAN = (0, 255, 255)

class Particle:
    def __init__(self, x, y, color, speed_x, speed_y, life):
        self.x = x
        self.y = y
        self.color = color
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.life = life
        self.max_life = life
        self.size = random.randint(2, 5)
    
    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
        self.life -= 1
        
        # Fade out over time
        alpha = self.life / self.max_life
        self.color = tuple(int(c * alpha) for c in self.color)
    
    def draw(self, surface):
        if self.life > 0:
            pygame.draw.circle(surface, self.color, (int(self.x), int(self.y)), 
                             max(1, int(self.size * (self.life / self.max_life))))

class Player:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.width = 40
        self.height = 30
        self.speed = 6
        self.health = 100
        self.max_health = 100
        self.shoot_cooldown = 0
        self.power_level = 1
        self.shield = False
        self.shield_timer = 0
    
    def update(self, keys):
        # Movement
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.x -= self.speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.x += self.speed
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.y -= self.speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.y += self.speed
        
        # Keep on screen
        self.x = max(0, min(self.x, SCREEN_WIDTH - self.width))
        self.y = max(0, min(self.y, SCREEN_HEIGHT - self.height))
        
        # Update cooldowns
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1
        
        if self.shield_timer > 0:
            self.shield_timer -= 1
            if self.shield_timer <= 0:
                self.shield = False
    
    def shoot(self):
        bullets = []
        if self.shoot_cooldown <= 0:
            if self.power_level == 1:
                bullets.append(Bullet(self.x + self.width // 2, self.y, 0, -8))
                self.shoot_cooldown = 15
            elif self.power_level == 2:
                bullets.append(Bullet(self.x + self.width // 2 - 5, self.y, 0, -8))
                bullets.append(Bullet(self.x + self.width // 2 + 5, self.y, 0, -8))
                self.shoot_cooldown = 12
            elif self.power_level >= 3:
                bullets.append(Bullet(self.x + self.width // 2, self.y, 0, -8))
                bullets.append(Bullet(self.x + self.width // 2 - 10, self.y, -2, -8))
                bullets.append(Bullet(self.x + self.width // 2 + 10, self.y, 2, -8))
                self.shoot_cooldown = 10
            damage_sound.play()
        return bullets
    
    def take_damage(self, damage):
        if not self.shield:
            self.health -= damage
            damage_sound.play()
            
            return True
        return False
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def draw(self, surface):
        # Draw player ship
        color = CYAN if self.shield else BLUE
        pygame.draw.polygon(surface, color, [
            (self.x + self.width // 2, self.y),
            (self.x, self.y + self.height),
            (self.x + self.width // 2, self.y + self.height - 10),
            (self.x + self.width, self.y + self.height)
        ])
        
        # Draw shield effect
        if self.shield:
            pygame.draw.circle(surface, CYAN, 
                             (self.x + self.width // 2, self.y + self.height // 2),
                             max(self.width, self.height) // 2 + 10, 2)

class Enemy:
    def __init__(self, x, y, enemy_type="basic"):
        self.x = x
        self.y = y
        self.type = enemy_type
        
        if enemy_type == "basic":
            self.width = 30
            self.height = 20
            self.speed = 2
            self.health = 20
            self.color = RED
            self.points = 10
        elif enemy_type == "fast":
            self.width = 20
            self.height = 15
            self.speed = 4
            self.health = 10
            self.color = ORANGE
            self.points = 20
        elif enemy_type == "tank":
            self.width = 40
            self.height = 30
            self.speed = 1
            self.health = 50
            self.color = PURPLE
            self.points = 50
        
        self.max_health = self.health
        self.shoot_timer = random.randint(60, 180)
    
    def update(self):
        self.y += self.speed
        self.shoot_timer -= 1
    
    def should_shoot(self):
        return self.shoot_timer <= 0 and random.random() < 0.02
    
    def shoot(self):
        if self.should_shoot():
            self.shoot_timer = random.randint(60, 180)
            return EnemyBullet(self.x + self.width // 2, self.y + self.height, 0, 4)
        return None
    
    def take_damage(self, damage):
        self.health -= damage
        return self.health <= 0
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def draw(self, surface):
        pygame.draw.rect(surface, self.color, self.get_rect())
        
        # Health bar for tanks
        if self.type == "tank":
            health_ratio = self.health / self.max_health
            bar_width = self.width
            bar_height = 4
            pygame.draw.rect(surface, RED, 
                           (self.x, self.y - 8, bar_width, bar_height))
            pygame.draw.rect(surface, GREEN, 
                           (self.x, self.y - 8, bar_width * health_ratio, bar_height))

class Bullet:
    def __init__(self, x, y, speed_x, speed_y):
        self.x = x
        self.y = y
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.width = 4
        self.height = 10
        self.damage = 10
    
    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def draw(self, surface):
        pygame.draw.rect(surface, YELLOW, self.get_rect())

class EnemyBullet:
    def __init__(self, x, y, speed_x, speed_y):
        self.x = x
        self.y = y
        self.speed_x = speed_x
        self.speed_y = speed_y
        self.width = 3
        self.height = 8
        self.damage = 20
    
    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def draw(self, surface):
        pygame.draw.rect(surface, RED, self.get_rect())

class PowerUp:
    def __init__(self, x, y, power_type):
        self.x = x
        self.y = y
        self.type = power_type
        self.width = 20
        self.height = 20
        self.speed = 2
        self.pulse = 0
        
        if power_type == "health":
            self.color = GREEN
        elif power_type == "power":
            self.color = YELLOW
        elif power_type == "shield":
            self.color = CYAN
    
    def update(self):
        self.y += self.speed
        self.pulse += 0.2
    
    def get_rect(self):
        return pygame.Rect(self.x, self.y, self.width, self.height)
    
    def draw(self, surface):
        size = self.width + math.sin(self.pulse) * 3
        pygame.draw.circle(surface, self.color, 
                         (int(self.x + self.width // 2), int(self.y + self.height // 2)),
                         int(size // 2))

class Game:
    def __init__(self):
        self.player = Player(SCREEN_WIDTH // 2, SCREEN_HEIGHT - 100)
        self.enemies = []
        self.bullets = []
        self.enemy_bullets = []
        self.power_ups = []
        self.particles = []
        
        self.score = 0
        self.level = 1
        self.enemy_spawn_timer = 0
        self.powerup_spawn_timer = 0
        
        self.font = pygame.font.Font(None, 36)
        self.font_large = pygame.font.Font(None, 48)
    
    def spawn_enemy(self):
        x = random.randint(0, SCREEN_WIDTH - 40)
        
        # Different enemy types based on level
        if self.level <= 2:
            enemy_type = "basic"
        elif self.level <= 5:
            enemy_type = random.choice(["basic", "fast"])
        else:
            enemy_type = random.choice(["basic", "fast", "tank"])
        
        self.enemies.append(Enemy(x, -50, enemy_type))
    
    def spawn_powerup(self):
        if random.random() < 0.3:  # 30% chance
            x = random.randint(0, SCREEN_WIDTH - 20)
            power_type = random.choice(["health", "power", "shield"])
            self.power_ups.append(PowerUp(x, -30, power_type))
    
    def create_explosion(self, x, y, color, count=10):
        for _ in range(count):
            speed_x = random.uniform(-5, 5)
            speed_y = random.uniform(-5, 5)
            life = random.randint(20, 40)
            self.particles.append(Particle(x, y, color, speed_x, speed_y, life))
    
    def update(self, keys):
        # Update player
        self.player.update(keys)
        
        # Player shooting
        if keys[pygame.K_SPACE]:
            new_bullets = self.player.shoot()
            self.bullets.extend(new_bullets)
        
        # Update bullets
        for bullet in self.bullets[:]:
            bullet.update()
            if bullet.y < 0:
                self.bullets.remove(bullet)
        
        for bullet in self.enemy_bullets[:]:
            bullet.update()
            if bullet.y > SCREEN_HEIGHT:
                self.enemy_bullets.remove(bullet)
        
        # Update enemies
        for enemy in self.enemies[:]:
            enemy.update()
            
            # Enemy shooting
            enemy_bullet = enemy.shoot()
            if enemy_bullet:
                self.enemy_bullets.append(enemy_bullet)
            
            # Remove enemies that are off screen
            if enemy.y > SCREEN_HEIGHT:
                self.enemies.remove(enemy)
        
        # Update power-ups
        for powerup in self.power_ups[:]:
            powerup.update()
            if powerup.y > SCREEN_HEIGHT:
                self.power_ups.remove(powerup)
        
        # Update particles
        for particle in self.particles[:]:
            particle.update()
            if particle.life <= 0:
                self.particles.remove(particle)
        
        # Collision detection
        self.check_collisions()
        
        # Spawn enemies
        self.enemy_spawn_timer += 1
        spawn_rate = max(30, 90 - self.level * 5)
        if self.enemy_spawn_timer >= spawn_rate:
            self.enemy_spawn_timer = 0
            self.spawn_enemy()
        
        # Spawn power-ups
        self.powerup_spawn_timer += 1
        if self.powerup_spawn_timer >= 600:  # Every 10 seconds
            self.powerup_spawn_timer = 0
            self.spawn_powerup()
        
        # Level progression
        if self.score >= self.level * 1000:
            self.level += 1
    
    def check_collisions(self):
        # Player bullets vs enemies
        for bullet in self.bullets[:]:
            for enemy in self.enemies[:]:
                if bullet.get_rect().colliderect(enemy.get_rect()):
                    self.bullets.remove(bullet)
                    if enemy.take_damage(bullet.damage):
                        self.score += enemy.points
                        self.create_explosion(enemy.x + enemy.width // 2, 
                                            enemy.y + enemy.height // 2, 
                                            enemy.color)
                        self.enemies.remove(enemy)
                    break
        
        # Enemy bullets vs player
        for bullet in self.enemy_bullets[:]:
            if bullet.get_rect().colliderect(self.player.get_rect()):
                self.enemy_bullets.remove(bullet)
                if self.player.take_damage(bullet.damage):
                    self.create_explosion(self.player.x + self.player.width // 2,
                                        self.player.y + self.player.height // 2,
                                        WHITE, 15)
        
        # Player vs enemies
        for enemy in self.enemies[:]:
            if enemy.get_rect().colliderect(self.player.get_rect()):
                if self.player.take_damage(30):
                    self.create_explosion(self.player.x + self.player.width // 2,
                                        self.player.y + self.player.height // 2,
                                        WHITE, 15)
                self.create_explosion(enemy.x + enemy.width // 2,
                                    enemy.y + enemy.height // 2,
                                    enemy.color)
                self.enemies.remove(enemy)
        
        # Player vs power-ups
        for powerup in self.power_ups[:]:
            if powerup.get_rect().colliderect(self.player.get_rect()):
                self.power_ups.remove(powerup)
                
                if powerup.type == "health":
                    self.player.health = min(self.player.max_health, 
                                           self.player.health + 30)
                elif powerup.type == "power":
                    self.player.power_level = min(3, self.player.power_level + 1)
                elif powerup.type == "shield":
                    self.player.shield = True
                    self.player.shield_timer = 300  # 5 seconds at 60 FPS
                
                self.create_explosion(powerup.x + powerup.width // 2,
                                    powerup.y + powerup.height // 2,
                                    powerup.color, 5)
    
    def draw(self, surface):
        surface.fill(BLACK)
        
        # Draw stars background
        for i in range(50):
            x = (i * 23) % SCREEN_WIDTH
            y = (i * 37 + pygame.time.get_ticks() // 10) % SCREEN_HEIGHT
            pygame.draw.circle(surface, WHITE, (x, y), 1)
        
        # Draw game objects
        self.player.draw(surface)
        
        for bullet in self.bullets:
            bullet.draw(surface)
        
        for bullet in self.enemy_bullets:
            bullet.draw(surface)
        
        for enemy in self.enemies:
            enemy.draw(surface)
        
        for powerup in self.power_ups:
            powerup.draw(surface)
        
        for particle in self.particles:
            particle.draw(surface)
        
        # Draw UI
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        surface.blit(score_text, (10, 10))
        
        level_text = self.font.render(f"Level: {self.level}", True, WHITE)
        surface.blit(level_text, (10, 50))
        
        power_text = self.font.render(f"Power: {self.player.power_level}", True, WHITE)
        surface.blit(power_text, (10, 90))
        
        # Health bar
        health_ratio = self.player.health / self.player.max_health
        bar_width = 200
        bar_height = 20
        pygame.draw.rect(surface, RED, (SCREEN_WIDTH - bar_width - 10, 10, bar_width, bar_height))
        pygame.draw.rect(surface, GREEN, (SCREEN_WIDTH - bar_width - 10, 10, bar_width * health_ratio, bar_height))
        
        health_text = self.font.render("Health", True, WHITE)
        surface.blit(health_text, (SCREEN_WIDTH - bar_width - 10, 35))
        
        # Instructions
        instruction_text = self.font.render("WASD/Arrows: Move, Space: Shoot", True, WHITE)
        surface.blit(instruction_text, (10, SCREEN_HEIGHT - 40))

async def run_game():
    global game, game_over

    # Create game
    game = Game()

    # Game loop
    running = True
    clock = pygame.time.Clock()
    game_over = False

    pygame.mixer.music.load("bg_music.ogg")
    pygame.mixer.music.play(-1)

    while running:
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r and game_over:
                    game = Game()
                    game_over = False

        if not game_over:
            keys = pygame.key.get_pressed()
            game.update(keys)
            if game.player.health <= 0:
                game_over = True

        game.draw(screen)

        if game_over:
            overlay = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
            overlay.set_alpha(128)
            overlay.fill(BLACK)
            screen.blit(overlay, (0, 0))

            game_over_text = game.font_large.render("GAME OVER", True, RED)
            game_over_rect = game_over_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 50))
            screen.blit(game_over_text, game_over_rect)

            final_score_text = game.font.render(f"Final Score: {game.score}", True, WHITE)
            final_score_rect = final_score_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2))
            screen.blit(final_score_text, final_score_rect)

            restart_text = game.font.render("Press R to restart", True, WHITE)
            restart_rect = restart_text.get_rect(center=(SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 + 50))
            screen.blit(restart_text, restart_rect)

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)

    pygame.quit()


asyncio.run(run_game())
